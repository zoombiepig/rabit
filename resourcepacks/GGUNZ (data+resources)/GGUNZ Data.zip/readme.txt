[===============================]
|                               |
|    --- GGUNZ by Geegaz ---    |
|                               |
|     a gun-themed datapack     |
|                               |
[===============================]
Do not repost, modify or claim this work as your own

/datapack enable "file/GGUNZ" to install the pack
/function ggunz:uninstall to remove the pack from your world

____________________________________________________
Features:
(use /function ggunz:recipe/give_items to recieve every item in the pack)

|Guns:
- Revolver - capacity: 6, reload time: 3s, uses bullets
- Etherium Gun - capacity: 4, reload time: 1.5s, uses Liquid Etherium
- Hunting Rifle - capacity: 2, reload time: 1s, uses Cartrige
- Etherium Rifle - capacity: 8, reload time: 2.5s, uses Liquid Etherium

|Ammos:
- Bullet - low damage
- Cartridge - high damage
- Liquid Etherium - low damage, freezes ennemy for 5s

|Weapons:
- Big Stick - weak, low damage
- Spear - low damage, fast
- Survival Knife - medium damage

|Items:
Craftable:
- Etherium - used to create liquid etherium
- Bandage - when used, heals 5 hearts in 10s
Uncraftable:
- Gold Coin
- Silver Coin
- Copper Coin
- Scroll
- Jerrycan - can be used as fuel

