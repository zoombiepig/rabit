[===============================]
|                               |
| - GGUNZ Resources by Geegaz - |
|                               |
|    Texture pack for GGUNZ     |
|                               |
[===============================]
Do not repost, modify or claim this work as your own

F3 + T to reload texture pack

____________________________________________________
Features:

|Textures:

[assets/minecraft/textures/custom/items]
- bandage.png
- big_stick.png
- bullet_0.png
- bullet_1.png
- bullet_2.png
- cardboard_box.png
- copper_coin.png
- etherium_rock.png
- gold_coin.png
- gun_0.png
- gun_1.png
- gun_2.png
- gun_3.png
- jerrycan.png
- scroll.png
- silver_coin.png
- spear.png
- survival_knife.png

[assets/minecraft/textures/custom]
- minecraft_items - all the items added by the pack

|Models:

[assets/minecraft/models/item] (regular items changed by the pack)
- barrier.json - for the datapack advancement tab
- carrot_on_a_stick.json - for unloaded guns and Bandage
- charcoal.json - for Jerrycan
- clock.json - for every item except Jerrycan and Bandage
- crossbow.json - for loaded guns
- iron_hoe.json - for Spear
- knowledge_book.json - placeholder item for crafting
- stone_sword.json - for Survival Knife
- wooden_sword.json - for Big Stick

[assets/minecraft/models/custom/item]
- bandage.json
- big_stick.json
- bullet_0.json
- bullet_1.json
- bullet_2.json
- copper_coin.json
- etherium_rock.json
- gold_coin.json
- gun_0.json
- gun_1.json
- gun_2.json
- gun_3.json
- jerrycan.json
- scroll.json
- silver_coin.json
- spear.json
- survival_knife.json

|Lang file:

[assets/minecraft/lang]
- en_us - texts of the datapack in english



